# Lampstage Creative Expert

This WorkBuddy Expert connects a user's workflow to the Lampstage API and combines five skills:

- product understanding from supplied facts and source assets
- ecommerce keyword and listing copy optimization
- image generation through `image-jobs`
- reference-video preparation and Hypit / RunningHub H3 rendering
- asset upload, job polling and output retrieval

## Configure the connector

1. Register at `https://lampstage.com` and create a personal API key at `/account`.
2. Import this directory as a WorkBuddy Expert package.
3. Connect the `lampstage` MCP dependency and enter the API key in WorkBuddy's token dialog.
4. The package connects to `https://lampstage.com/api/mcp`, which forwards to the versioned `/api/v1` API.

The connector declaration uses the standard `streamable-http` transport type. The package keeps the MCP configuration in the root `.mcp.json`; do not remove or rename this hidden file when repacking.

The Expert checks `health`, `capabilities` and the actual tool input contract before write operations. Paid preparation, rendering and repairs must fit the user's authorization and budget; preparation generates reference images and is not assumed to be free. It does not expose provider credentials.

## Infant clothing replication guidance · 0.2.1

For baby clothing demonstrations, baby/mother replacement and bedsheet color changes, the Expert loads the [infant clothing guide](skills/video-generation/references/infant-clothing.md) and [production review record](skills/video-generation/references/replication-review-template.md). They cover confirmed product structure, action completeness, compatible shot reuse, localized repairs, audio review and attempt/cost tracking.

These are production and review rules derived from prior cases. They do not add independent identity slots, custom segmentation, mask recoloring, selected-segment submission or narration tools to the API, and do not guarantee one-shot success. Requirements needing unavailable controls are identified before paid generation.

Import this version again to receive the new guidance. An older installed package does not automatically read future local knowledge-base updates.

## Runtime readiness

The package structure and bundled bridge can be validated without provider calls. Real image/video jobs require the Lampstage production database migrations, object storage credentials and worker runtime to be healthy. A `503` health response means the package imported successfully but the API is not ready to accept tasks yet.

The bundled bridge accepts source assets through a public `http(s)` URL so the server can fetch them safely. Validate one publicly readable image URL before testing an image job; a local file path or a private-network URL will be rejected by design.
